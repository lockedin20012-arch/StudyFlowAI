# StudyFlow AI

An AI study platform: Homework Helper, Quiz Maker, Flashcards, Study Guide, AI Tutor,
and Practice Tests, plus a Stripe-powered Plus plan.

## How this is wired up

- **Frontend**: Vite + React + Tailwind (`src/App.jsx`).
- **AI calls**: the frontend calls `/api/claude`, a small serverless function
  (`api/claude.js`) that holds your real Anthropic API key server-side and forwards
  the request. The key is never sent to the browser.
- **Billing**: Stripe Payment Links (`STRIPE_PAYMENT_LINKS` near the top of `App.jsx`).
  No backend needed for checkout itself, but see the note in `App.jsx` about webhooks
  if you want plan upgrades to be verified automatically.
- **Storage**: your subjects, saved materials, and quiz history are stored in the
  browser's `localStorage`, per device/browser. There's no shared account database yet
  — see "Next steps" below if you want real accounts.

## Local development

```bash
npm install
cp .env.example .env        # then paste your real Anthropic key into .env
npm run dev
```

Note: `npm run dev` (plain Vite) won't run the `/api/claude` serverless function.
To test AI calls locally, install the Vercel CLI and run `vercel dev` instead —
it runs both the frontend and the `/api` functions together.

## Deploying to Vercel

1. Push this whole folder to your GitHub repo (not just `App.jsx` — Vercel needs
   `package.json`, `vite.config.js`, `index.html`, etc. to know how to build it).
2. In Vercel, import the repo. It will auto-detect Vite.
3. Go to your Vercel project → **Settings → Environment Variables** and add:
   - `ANTHROPIC_API_KEY` = your real key from console.anthropic.com
4. Redeploy. The AI tools will now work through `/api/claude`.

## Stripe

`STRIPE_PAYMENT_LINKS` in `src/App.jsx` currently points at test-mode links. Swap in
your live Payment Link URLs before accepting real payments (see the in-app note on
the Billing page for details on why upgrades still need a manual confirmation step
until a webhook-backed backend is added).

## Next steps for a production launch

- Real accounts + a database (so materials/progress aren't tied to one browser).
- A webhook endpoint for Stripe (`checkout.session.completed`,
  `customer.subscription.*`) to auto-activate/cancel Plus instead of the manual
  confirmation button.
- Rate limiting / usage checks on `/api/claude` itself, since the current free-tier
  limit is enforced client-side only.
